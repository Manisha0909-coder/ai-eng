# UI-000 · EPIC — UI Consistency & Design System Refactor

**Type:** Epic  
**Priority:** High  
**Owner:** Tech Lead  
**Status:** Planning

## Goal

Make the UI consistent and maintainable so that one change to a design token or primitive component propagates everywhere automatically.

Replace the custom `useTheme` hook system (446 lines of JS setting CSS properties imperatively) with Tailwind-native theming: CSS variables in `index.css`, toggled via a class or `data-theme` attribute on `<html>`. No JavaScript needed to apply a theme.

## Problem Summary

| Issue | Impact |
|-------|--------|
| `useTheme` hook managing themes in JS | Duplicates what CSS + Tailwind already do natively |
| Two parallel theme systems | Changes to either don't propagate everywhere |
| Hardcoded hex colors in feature files | Theme switching breaks those components |
| Arbitrary Tailwind values (`h-[28px]`, `text-[10px]`) in 30+ files | Cannot update sizing from one place |
| Duplicated carousel and dropdown components | Developers pick at random; fixes applied twice |
| Every modal has a custom `max-w-[Xpx]` | No consistent dialog sizing |

## Architecture Decision

```css
/* index.css — single source of truth */
:root          { --color-primary: 59 130 246; }
.dark          { --color-primary: 99 102 241; }
[data-theme="uae"] { --color-primary: 182 138 53; }
```

```ts
// Switch theme — no hook, no React, no broadcast
document.documentElement.classList.toggle('dark')
document.documentElement.setAttribute('data-theme', 'client-id')
```

## Child Tickets

| Ticket | Title | Sprint | Blocked By |
|--------|-------|--------|------------|
| [UI-011](./UI-011-remove-usetheme.md) | Remove useTheme system (31 consumers) | 1 | — |
| [UI-012](./UI-012-tenant-config.md) | Separate tenant asset config | 1 | UI-011 |
| [UI-005](./UI-005-merge-carousel.md) | Merge carousel components | 1 | — |
| [UI-006](./UI-006-merge-combobox.md) | Extend Combobox, deprecate SearchableDropdown (14 consumers) | 1 | — |
| [UI-007](./UI-007-form-cleanup.md) | Form system cleanup + raw input audit | 1 | — |
| [UI-001](./UI-001-design-tokens.md) | Restructure CSS tokens + Tailwind config | 2 | UI-011 |
| [UI-002](./UI-002-hardcoded-colors-payment.md) | Purge hardcoded colors — PaymentForm | 3 | UI-001 |
| [UI-003](./UI-003-hardcoded-colors-chat.md) | Purge hardcoded colors — Chat components | 3 | UI-001 |
| [UI-004](./UI-004-hardcoded-colors-settings.md) | Purge hardcoded colors — Settings | 3 | UI-001 |
| [UI-008](./UI-008-modal-sizing.md) | Standardize modal/dialog sizing | 3 | UI-001 |
| [UI-009](./UI-009-arbitrary-tailwind.md) | Global sweep — replace arbitrary Tailwind values | 3 | UI-001 |
| [UI-010](./UI-010-inline-styles.md) | Inline style cleanup | 4 | UI-001, UI-002 |
| [UI-013](./UI-013-hardcoded-color-check-script.md) | Hardcoded color check script + CI | 2 | — |

## Sprint Plan

```
Sprint 1 (parallel, all independent):
  UI-011  Remove useTheme + ThemeService + ThemesData
  UI-005  Merge carousel
  UI-006  Extend Combobox / drop SearchableDropdown
  UI-007  Form cleanup

Sprint 2:
  UI-012  Tenant asset config (depends on UI-011)
  UI-001  CSS token restructure + Tailwind config (depends on UI-011)

Sprint 3 (parallel, all depend on UI-001):
  UI-002  Purge hardcoded colors — PaymentForm
  UI-003  Purge hardcoded colors — Chat
  UI-004  Purge hardcoded colors — Settings
  UI-008  Modal sizing tokens
  UI-009  Arbitrary Tailwind value sweep

Sprint 4:
  UI-010  Inline style cleanup
```

## Definition of Done

- `grep -r 'useTheme' src/` returns zero results
- Toggle dark class on `<html>` → all components recolor with no JS
- Set `data-theme="uae"` on `<html>` → primary color shifts to gold everywhere
- `grep -r '#[0-9a-fA-F]\{6\}' src/features/` returns only intentional OAuth brand values
- `grep -r 'bg-\[var\|text-\[var\|border-\[var' src/features/` returns zero results
- `npm run build` passes after every sprint
